from django.shortcuts import render, redirect
from django.urls import reverse
from django.http import JsonResponse
import epaycosdk.epayco as epayco
# Create your views here.

def index(request):

	return render(request, 'base/index.html')


def charge(request):


	if request.method == 'POST':
		print('Data:', request.POST)

		amount = int(request.POST['amount'])
		apiKey = "PUBLIC_KEY"
		privateKey = "PRIVATE_KEY"
		lenguage = "ES"
		test = True
		options={"apiKey":apiKey,"privateKey":privateKey,"test":test,"lenguage":lenguage}	
		objepayco=epayco.Epayco(options)

		customer_info = {
		"token_card": request.POST['epaycoToken'],
		"name": request.POST['nickname'],
		"last_name": request.POST['nickname'], #This parameter is optional
		"email": request.POST['email'],
		"phone": "3005234321",
		"default": true
		}
		customer=objepayco.customer.create(customer_info)

	return redirect(reverse('success', args=[amount]))


def successMsg(request, args):
	amount = args
	return render(request, 'base/success.html', {'amount':amount})